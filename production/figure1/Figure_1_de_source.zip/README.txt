German version of Figure 1

Extract this archive into a separate folder outside a Quarto project.
Run: quarto render Figure_1_de.qmd

The source retains the original LightLogR workflow and translates only presentation text and number formatting.
The German figure has no caption. Its accessible description is in Figure_1_de_alt_text.txt.
The original derived data are included for exact equality checks in R.
See Figure_1_de_reproducibility.txt for R, Quarto and package versions and input checksums.
