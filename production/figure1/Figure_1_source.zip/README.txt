Figure 1 reproduction package

Unzip this archive into a folder and run:
  quarto render Figure_1.qmd

This recreates Figure_1.pdf (vector, 180 x 120 mm) and Figure_1.png
(600 dpi), and writes the exact plot data into figure1_data/intermediate.
The source is a reduced Quarto copy of the LightLogR Day.Rmd workflow.
Input data are bundled copies of the LightLogR example data.

Requirements: R, Quarto, LightLogR, dplyr, lubridate, ggplot2, patchwork,
hms, tibble, ragg, knitr. Tested versions and input checksums are recorded
in Figure_1_reproducibility.txt. No package installation is performed.

The new strip uses Tuebingen coordinates from LightLogR documentation,
Europe/Berlin time, and solar depression 6 degrees on 1 September 2023.
The original reference alignment, five-minute rounding/aggregation and
Brown recommendation classification are retained. The graph uses the
original symmetric-log transform and supports zero measurements.

The figure caption and alt text are in Figure_1_caption_and_alt_text.txt.
No online proof was changed, saved, or submitted.
